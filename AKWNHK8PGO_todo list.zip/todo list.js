function addTodo() {
    var todoInput = document.getElementById("todo-input").value;
    if (todoInput === '') {
        alert("Please enter a todo!");
        return;
    }
    var todoList = document.getElementById("todo-list");
    var li = document.createElement("li");
    li.textContent = todoInput;
    todoList.appendChild(li);
    document.getElementById("todo-input").value = '';
}